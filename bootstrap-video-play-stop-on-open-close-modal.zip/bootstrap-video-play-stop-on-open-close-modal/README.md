# Bootstrap video Play Stop on Open Close modal

A Pen created on CodePen.io. Original URL: [https://codepen.io/Albesku/pen/YBLvyW](https://codepen.io/Albesku/pen/YBLvyW).

Bootstrap Play/Stop video on open/close the modal which contents it. No matter how many modals you add. The video will be played on show modal, and will be stopped and reset to 0 on close modal.
This problem came up while creating a website with video inside modals, which should be triggered by showing the modal and stopped when hide. I worked around to find a solution to work with all modal IDs which can be created on a website and plays only the video which is in opened modal.